---
name: face-recognition
description: Face recognition and emotion detection using FaceRecognitionDotNet and camera input. Use when: (1) Identifying faces in images or video streams, (2) Detecting facial emotions/expressions, (3) Comparing faces against known persons database, (4) Real-time face tracking from webcam or camera feeds, (5) Analyzing facial landmarks or features.
---

# Face Recognition

## Overview

This skill enables face detection, recognition, and emotion analysis using FaceRecognitionDotNet library with camera input support. It can identify known individuals, detect emotions, and track faces in real-time from webcam or image files.

## Core Capabilities

### 1. Face Detection
Detect faces in images or video frames and return bounding box coordinates.

**Example requests:**
- "Detect all faces in this image"
- "How many people are in this photo?"
- "Find faces in the webcam feed"

### 2. Face Recognition
Identify individuals by comparing detected faces against a database of known persons.

**Example requests:**
- "Who is in this picture?"
- "Recognize people from the camera feed"
- "Check if this person is in my contacts"

### 3. Emotion Detection
Analyze facial expressions to detect emotions (happy, sad, angry, surprised, etc.).

**Example requests:**
- "What emotion is this person showing?"
- "Detect the mood of people in this video"
- "Analyze facial expressions from webcam"

### 4. Real-time Camera Processing
Process live video streams from connected cameras for continuous face tracking.

**Example requests:**
- "Track faces from my webcam"
- "Monitor who enters the room using camera"
- "Run face recognition on camera feed"

## Workflow

### Step 1: Check Camera Availability
Before processing, verify camera access and list available devices:

```bash
# List available cameras
python3 scripts/list_cameras.py
```

### Step 2: Prepare Face Database (for recognition)
If performing face recognition (not just detection), prepare known faces:

```bash
# Add a known person's face to database
python3 scripts/add_face.py --name "John Doe" --image path/to/photo.jpg
```

### Step 3: Run Face Analysis
Choose the appropriate script based on your task:

**Face Detection Only:**
```bash
python3 scripts/detect_faces.py --input image.jpg
```

**Face Recognition:**
```bash
python3 scripts/recognize_faces.py --input image.jpg --database faces_db/
```

**Emotion Detection:**
```bash
python3 scripts/detect_emotions.py --input image.jpg
```

**Real-time Camera Processing:**
```bash
python3 scripts/camera_face_tracking.py --camera 0 --mode recognition
```

### Step 4: Review Results
Results are output as JSON with:
- Face locations (top, right, bottom, left coordinates)
- Confidence scores
- Identified person names (for recognition)
- Emotion labels and confidence (for emotion detection)

## Configuration

### Camera Settings
- Default camera index: `0` (first webcam)
- Frame resolution: Configurable (default 640x480)
- FPS limit: Configurable for performance

### Face Database
- Location: `faces_db/` directory in workspace
- Format: One folder per person with multiple face encodings
- Minimum images per person: 3 recommended for accuracy

### Performance Tuning
- For real-time processing, use `--upsample 0` to skip image upsampling
- Set `--num-jitters 1` for faster encoding (reduce from default 5)
- Use `--model cnn` for GPU acceleration if available

## Scripts Reference

| Script | Purpose | Input | Output |
|--------|---------|-------|--------|
| `list_cameras.py` | List available camera devices | None | Camera indices and names |
| `add_face.py` | Add known face to database | Image file, person name | Face encoding saved |
| `detect_faces.py` | Detect faces in image/video | Image or video file | Face locations |
| `recognize_faces.py` | Identify known faces | Image, face database | Person names + locations |
| `detect_emotions.py` | Analyze facial emotions | Image or video file | Emotion labels |
| `camera_face_tracking.py` | Real-time camera processing | Camera index | Continuous face data |

## Troubleshooting

### Camera Not Detected
- Check camera permissions in system settings
- Try different camera index (`--camera 1`, `--camera 2`, etc.)
- Verify camera works with other applications

### Recognition Accuracy Low
- Add more reference images per person (5+ recommended)
- Ensure good lighting in reference photos
- Use front-facing, clear images for database

### Performance Issues
- Reduce frame resolution for real-time processing
- Lower FPS target (`--fps 15`)
- Use CPU-only mode if GPU causes issues

## Dependencies

This skill requires:
- .NET 6.0+ runtime
- FaceRecognitionDotNet NuGet package
- OpenCV for camera input
- Emotion detection model (included in scripts)

Install dependencies:
```bash
dotnet add package FaceRecognitionDotNet
dotnet add package OpenCvSharp4
```

## Security & Privacy

- Face data is stored locally in `faces_db/`
- No cloud processing - all analysis is local
- Delete `faces_db/` to remove all stored face encodings
- Camera access requires explicit user permission

## Related Resources

- See `references/face-api.md` for detailed API documentation
- See `references/emotion-models.md` for emotion detection model details
