# Face Recognition Skill - Dependencies & Setup

## Required Dependencies

### Python Packages

```bash
pip install face_recognition opencv-python numpy
```

### System Dependencies

#### Ubuntu/Debian

```bash
# Install dlib dependencies
sudo apt-get install -y build-essential cmake
sudo apt-get install -y libopenblas-dev liblapack-dev
sudo apt-get install -y libx11-dev libgtk-3-dev

# Install dlib (required by face_recognition)
pip install dlib
```

#### macOS

```bash
# Install dependencies via Homebrew
brew install cmake
brew install dlib

# Install Python packages
pip install face_recognition opencv-python numpy
```

#### Windows

```bash
# Install Visual Studio Build Tools (required for dlib)
# Download from: https://visualstudio.microsoft.com/downloads/

# Install Python packages
pip install face_recognition opencv-python numpy
```

## Optional: GPU Acceleration

For faster face detection using CNN model:

### With CUDA

```bash
# Install dlib with CUDA support
pip install dlib --global-option=build_ext --global-option="-DCUDA_VERBOSE_BUILD=ON"

# Or build from source with CUDA enabled
git clone https://github.com/davisking/dlib.git
cd dlib
mkdir build && cd build
cmake .. -DDLIB_USE_CUDA=1 -DUSE_AVX_INSTRUCTIONS=1
cmake --build .
cd ..
python setup.py install
```

## Camera Permissions

### macOS
Go to System Preferences → Security & Privacy → Privacy → Camera
Ensure your terminal/Python has camera access.

### Windows
Go to Settings → Privacy → Camera
Allow apps to access your camera.

### Linux
Ensure user is in video group:
```bash
sudo usermod -a -G video $USER
```

## Quick Start

1. **List available cameras:**
   ```bash
   python scripts/list_cameras.py
   ```

2. **Add known faces to database:**
   ```bash
   python scripts/add_face.py --name "John Doe" --image john.jpg
   ```

3. **Detect faces in an image:**
   ```bash
   python scripts/detect_faces.py --input photo.jpg
   ```

4. **Recognize faces:**
   ```bash
   python scripts/recognize_faces.py --input photo.jpg --database faces_db
   ```

5. **Real-time camera tracking:**
   ```bash
   python scripts/camera_face_tracking.py --camera 0 --mode recognize
   ```

## Troubleshooting

### "No module named 'face_recognition'"
```bash
pip install face_recognition
```

### "No cameras detected"
- Check camera permissions
- Try different camera index (--camera 1, --camera 2)
- Verify camera works in other applications

### "dlib installation failed"
- Ensure cmake is installed
- Install system dependencies (see above)
- Try: `pip install dlib --verbose`

### Slow performance
- Use `--upsample 0` to skip image upsampling
- Use `--model hog` instead of `cnn` for detection
- Reduce camera resolution in script settings
