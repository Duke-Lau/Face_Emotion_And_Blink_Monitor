#!/usr/bin/env python3
"""
Add a known face to the face recognition database.
"""

import sys
import os
import argparse
import json
import numpy as np

try:
    import face_recognition
except ImportError:
    print("Error: face_recognition not installed. Run: pip install face_recognition", file=sys.stderr)
    sys.exit(1)


def load_image(image_path):
    """Load an image file."""
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}")
    
    image = face_recognition.load_image_file(image_path)
    return image


def encode_face(image, num_jitters=5):
    """Generate face encoding from an image."""
    face_locations = face_recognition.face_locations(image)
    
    if not face_locations:
        return None, "No face detected in image"
    
    if len(face_locations) > 1:
        return None, f"Multiple faces detected ({len(face_locations)}). Please use an image with one clear face."
    
    face_encodings = face_recognition.face_encodings(image, face_locations, num_jitters=num_jitters)
    
    if not face_encodings:
        return None, "Could not encode face"
    
    return face_encodings[0], None


def save_face_encoding(name, encoding, database_path="faces_db"):
    """Save face encoding to the database."""
    # Create database directory if it doesn't exist
    person_dir = os.path.join(database_path, name.replace(" ", "_").lower())
    os.makedirs(person_dir, exist_ok=True)
    
    # Find next available filename
    existing_files = [f for f in os.listdir(person_dir) if f.endswith(".npy")]
    next_index = len(existing_files) + 1
    
    # Save encoding
    filename = f"encoding_{next_index:03d}.npy"
    filepath = os.path.join(person_dir, filename)
    np.save(filepath, encoding)
    
    return filepath


def main():
    parser = argparse.ArgumentParser(description="Add a known face to the recognition database")
    parser.add_argument("--name", required=True, help="Name of the person")
    parser.add_argument("--image", required=True, help="Path to image file")
    parser.add_argument("--database", default="faces_db", help="Database directory (default: faces_db)")
    parser.add_argument("--num-jitters", type=int, default=5, help="Number of jitters for encoding (default: 5)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    try:
        # Load image
        image = load_image(args.image)
        
        # Encode face
        encoding, error = encode_face(image, num_jitters=args.num_jitters)
        
        if error:
            result = {"success": False, "error": error}
            if args.json:
                print(json.dumps(result, indent=2))
            else:
                print(f"Error: {error}")
            sys.exit(1)
        
        # Save to database
        filepath = save_face_encoding(args.name, encoding, args.database)
        
        result = {
            "success": True,
            "name": args.name,
            "encoding_file": filepath,
            "database": args.database
        }
        
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"✓ Added face encoding for '{args.name}'")
            print(f"  Saved to: {filepath}")
        
    except Exception as e:
        result = {"success": False, "error": str(e)}
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
