#!/usr/bin/env python3
"""
Real-time face tracking from camera feed.
Supports detection, recognition, and emotion analysis modes.
"""

import sys
import os
import argparse
import json
import time
import numpy as np

try:
    import cv2
    import face_recognition
except ImportError:
    print("Error: Required packages not installed. Run: pip install opencv-python face_recognition", file=sys.stderr)
    sys.exit(1)


def load_face_database(database_path):
    """Load all face encodings from the database."""
    known_faces = {}
    
    if not os.path.exists(database_path):
        return known_faces
    
    for person_name in os.listdir(database_path):
        person_dir = os.path.join(database_path, person_name)
        if not os.path.isdir(person_dir):
            continue
        
        person_encodings = []
        for filename in os.listdir(person_dir):
            if filename.endswith(".npy"):
                filepath = os.path.join(person_dir, filename)
                encoding = np.load(filepath)
                person_encodings.append(encoding)
        
        if person_encodings:
            known_faces[person_name.replace("_", " ").title()] = np.mean(person_encodings, axis=0)
    
    return known_faces


def process_frame(frame, known_faces, mode="detect", tolerance=0.6):
    """Process a single video frame for face analysis."""
    # Convert BGR to RGB for face_recognition
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    # Resize frame for faster processing (optional)
    small_frame = cv2.resize(rgb_frame, (0, 0), fx=0.25, fy=0.25)
    
    # Detect faces
    face_locations = face_recognition.face_locations(small_frame, number_of_times_to_upsample=0)
    
    results = []
    
    if mode == "recognize" and known_faces:
        face_encodings = face_recognition.face_encodings(small_frame, face_locations)
        
        for i, (top, right, bottom, left) in enumerate(face_locations):
            # Scale back up
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4
            
            face_result = {
                "location": {"top": top, "right": right, "bottom": bottom, "left": left},
                "recognized": False,
                "name": "Unknown"
            }
            
            if i < len(face_encodings):
                face_encoding = face_encodings[i]
                distances = face_recognition.face_distance(list(known_faces.values()), face_encoding)
                best_match_idx = np.argmin(distances)
                best_distance = distances[best_match_idx]
                
                if best_distance <= tolerance:
                    face_result["recognized"] = True
                    face_result["name"] = list(known_faces.keys())[best_match_idx]
            
            results.append(face_result)
    
    elif mode == "detect":
        for top, right, bottom, left in face_locations:
            # Scale back up
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4
            
            results.append({
                "location": {"top": top, "right": right, "bottom": bottom, "left": left},
                "detected": True
            })
    
    return results


def run_camera_tracking(camera_index=0, mode="detect", database=None, tolerance=0.6, fps_limit=15):
    """Run real-time face tracking from camera."""
    
    # Load face database if in recognition mode
    known_faces = {}
    if mode == "recognize" and database:
        known_faces = load_face_database(database)
        if not known_faces:
            print(f"Warning: No faces found in database '{database}'. Falling back to detection mode.")
            mode = "detect"
    
    # Open camera
    cap = cv2.VideoCapture(camera_index)
    
    if not cap.isOpened():
        return {"success": False, "error": f"Cannot open camera {camera_index}"}
    
    # Set camera properties
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    
    frame_count = 0
    start_time = time.time()
    results = []
    
    print(f"Starting face {mode} from camera {camera_index}...")
    print("Press 'q' to quit")
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            frame_count += 1
            
            # Process frame
            frame_results = process_frame(frame, known_faces, mode, tolerance)
            results.append({"frame": frame_count, "faces": frame_results})
            
            # Draw results on frame
            for face in frame_results:
                loc = face["location"]
                top, right, bottom, left = loc["top"], loc["right"], loc["bottom"], loc["left"]
                
                # Draw rectangle
                color = (0, 255, 0) if face.get("recognized", True) else (0, 0, 255)
                cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
                
                # Draw label
                if mode == "recognize":
                    label = f"{face.get('name', 'Unknown')} ({face.get('confidence', 0):.0%})"
                    cv2.putText(frame, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            
            # Display frame
            cv2.imshow('Face Tracking', frame)
            
            # Check for quit
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            
            # Frame rate limiting
            elapsed = time.time() - start_time
            expected_frames = elapsed * fps_limit
            if frame_count > expected_frames:
                time.sleep(0.01)
    
    except KeyboardInterrupt:
        pass
    finally:
        cap.release()
        cv2.destroyAllWindows()
    
    # Calculate stats
    total_time = time.time() - start_time
    avg_fps = frame_count / total_time if total_time > 0 else 0
    
    summary = {
        "success": True,
        "mode": mode,
        "camera": camera_index,
        "frames_processed": frame_count,
        "duration_seconds": round(total_time, 2),
        "average_fps": round(avg_fps, 2),
        "total_faces_detected": sum(len(r["faces"]) for r in results)
    }
    
    return summary


def main():
    parser = argparse.ArgumentParser(description="Real-time face tracking from camera")
    parser.add_argument("--camera", type=int, default=0, help="Camera index (default: 0)")
    parser.add_argument("--mode", choices=["detect", "recognize", "emotion"], default="detect", help="Processing mode (default: detect)")
    parser.add_argument("--database", default="faces_db", help="Face database for recognition mode")
    parser.add_argument("--tolerance", type=float, default=0.6, help="Recognition tolerance (default: 0.6)")
    parser.add_argument("--fps", type=int, default=15, help="Target FPS (default: 15)")
    parser.add_argument("--json", action="store_true", help="Output summary as JSON")
    
    args = parser.parse_args()
    
    try:
        summary = run_camera_tracking(
            camera_index=args.camera,
            mode=args.mode,
            database=args.database,
            tolerance=args.tolerance,
            fps_limit=args.fps
        )
        
        if args.json:
            print(json.dumps(summary, indent=2))
        else:
            print("\n--- Session Summary ---")
            print(f"Mode: {summary['mode']}")
            print(f"Camera: {summary['camera']}")
            print(f"Frames processed: {summary['frames_processed']}")
            print(f"Duration: {summary['duration_seconds']}s")
            print(f"Average FPS: {summary['average_fps']}")
            print(f"Total faces detected: {summary['total_faces_detected']}")
    
    except Exception as e:
        summary = {"success": False, "error": str(e)}
        if args.json:
            print(json.dumps(summary, indent=2))
        else:
            print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
