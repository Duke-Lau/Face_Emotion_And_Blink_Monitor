#!/usr/bin/env python3
"""
Detect emotions from facial expressions.
"""

import sys
import os
import argparse
import json
import numpy as np

try:
    import cv2
    import face_recognition
except ImportError:
    print("Error: Required packages not installed. Run: pip install opencv-python face_recognition", file=sys.stderr)
    sys.exit(1)

# Emotion labels for FER model
EMOTION_LABELS = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']


def extract_face_roi(image_path, face_location):
    """Extract face region of interest from image."""
    image = face_recognition.load_image_file(image_path)
    top, right, bottom, left = face_location
    
    # Convert RGB to BGR for OpenCV
    image_bgr = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    
    # Extract face region
    face_roi = image_bgr[top:bottom, left:right]
    
    return face_roi


def predict_emotion(face_roi):
    """
    Predict emotion from face ROI using simple heuristic analysis.
    Note: For production use, integrate with a trained emotion detection model
    like FER, DeepFace, or a custom CNN model.
    """
    # This is a placeholder implementation
    # In production, load a pre-trained model like:
    # from fer import FER
    # detector = FER()
    # emotions = detector.detect_emotions(face_roi)
    
    # Placeholder: return neutral with low confidence
    # This should be replaced with actual model inference
    return {
        "emotions": {
            "neutral": 0.5,
            "happy": 0.2,
            "sad": 0.1,
            "angry": 0.1,
            "surprise": 0.05,
            "fear": 0.03,
            "disgust": 0.02
        },
        "dominant_emotion": "neutral"
    }


def detect_emotions_in_image(image_path, upsample=1):
    """Detect emotions for all faces in an image."""
    image = face_recognition.load_image_file(image_path)
    
    # Detect faces
    face_locations = face_recognition.face_locations(image, number_of_times_to_upsample=upsample)
    
    # Get face encodings (for alignment if needed)
    face_encodings = face_recognition.face_encodings(image, face_locations)
    
    results = []
    for i, (top, right, bottom, left) in enumerate(face_locations):
        face_result = {
            "face_id": i + 1,
            "location": {
                "top": top,
                "right": right,
                "bottom": bottom,
                "left": left
            },
            "emotions": {},
            "dominant_emotion": None,
            "confidence": 0.0
        }
        
        # Extract face ROI
        face_roi = image[top:bottom, left:right]
        
        # Convert to BGR for OpenCV-based models
        face_roi_bgr = cv2.cvtColor(face_roi, cv2.COLOR_RGB2BGR)
        
        # Predict emotion
        emotion_result = predict_emotion(face_roi_bgr)
        
        face_result["emotions"] = emotion_result["emotions"]
        face_result["dominant_emotion"] = emotion_result["dominant_emotion"]
        face_result["confidence"] = emotion_result["emotions"].get(emotion_result["dominant_emotion"], 0.0)
        
        results.append(face_result)
    
    return results


def main():
    parser = argparse.ArgumentParser(description="Detect emotions from facial expressions")
    parser.add_argument("--input", required=True, help="Input image file")
    parser.add_argument("--upsample", type=int, default=1, help="Number of times to upsample image (default: 1)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.input):
        result = {"success": False, "error": f"File not found: {args.input}"}
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"Error: {result['error']}")
        sys.exit(1)
    
    try:
        # Detect emotions
        faces = detect_emotions_in_image(args.input, upsample=args.upsample)
        
        result = {
            "success": True,
            "input": args.input,
            "face_count": len(faces),
            "faces": faces
        }
        
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"Analyzed {len(faces)} face(s) in {args.input}:")
            print()
            for face in faces:
                loc = face["location"]
                print(f"  Face {face['face_id']}:")
                print(f"    Dominant emotion: {face['dominant_emotion']} ({face['confidence']*100:.1f}%)")
                print(f"    All emotions:")
                for emotion, confidence in sorted(face["emotions"].items(), key=lambda x: -x[1]):
                    print(f"      - {emotion}: {confidence*100:.1f}%")
                print()
        
    except Exception as e:
        result = {"success": False, "error": str(e)}
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
