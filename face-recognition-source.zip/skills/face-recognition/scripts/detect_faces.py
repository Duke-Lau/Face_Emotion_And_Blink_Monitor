#!/usr/bin/env python3
"""
Detect faces in images or video files.
"""

import sys
import os
import argparse
import json

try:
    import face_recognition
except ImportError:
    print("Error: face_recognition not installed. Run: pip install face_recognition", file=sys.stderr)
    sys.exit(1)


def detect_faces_in_image(image_path, model="hog", upsample=1):
    """Detect faces in an image and return locations."""
    image = face_recognition.load_image_file(image_path)
    
    # Detect faces
    face_locations = face_recognition.face_locations(image, number_of_times_to_upsample=upsample, model=model)
    
    results = []
    for i, (top, right, bottom, left) in enumerate(face_locations):
        results.append({
            "face_id": i + 1,
            "location": {
                "top": top,
                "right": right,
                "bottom": bottom,
                "left": left
            },
            "width": right - left,
            "height": bottom - top
        })
    
    return results


def main():
    parser = argparse.ArgumentParser(description="Detect faces in images or video")
    parser.add_argument("--input", required=True, help="Input image or video file")
    parser.add_argument("--model", choices=["hog", "cnn"], default="hog", help="Detection model (default: hog)")
    parser.add_argument("--upsample", type=int, default=1, help="Number of times to upsample image (default: 1)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.input):
        result = {"success": False, "error": f"File not found: {args.input}"}
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"Error: {result['error']}")
        sys.exit(1)
    
    try:
        # Check file extension
        ext = os.path.splitext(args.input)[1].lower()
        video_exts = ['.mp4', '.avi', '.mov', '.mkv', '.wmv']
        
        if ext in video_exts:
            result = {"success": False, "error": "Video processing not yet implemented. Use image files for now."}
            if args.json:
                print(json.dumps(result, indent=2))
            else:
                print(f"Error: {result['error']}")
            sys.exit(1)
        
        # Detect faces in image
        faces = detect_faces_in_image(args.input, model=args.model, upsample=args.upsample)
        
        result = {
            "success": True,
            "input": args.input,
            "face_count": len(faces),
            "faces": faces
        }
        
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"Found {len(faces)} face(s) in {args.input}:")
            for face in faces:
                loc = face["location"]
                print(f"  Face {face['face_id']}: {face['width']}x{face['height']} at ({loc['left']}, {loc['top']}) to ({loc['right']}, {loc['bottom']})")
        
    except Exception as e:
        result = {"success": False, "error": str(e)}
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
