#!/usr/bin/env python3
"""
List available camera devices on the system.
"""

import sys
import json

try:
    import cv2
except ImportError:
    print("Error: OpenCV not installed. Run: pip install opencv-python", file=sys.stderr)
    sys.exit(1)


def list_cameras():
    """List all available camera devices."""
    cameras = []
    
    # Try indices 0-9
    for index in range(10):
        cap = cv2.VideoCapture(index)
        if cap.isOpened():
            # Get camera properties
            width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
            height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            fps = cap.get(cv2.CAP_PROP_FPS)
            
            cameras.append({
                "index": index,
                "available": True,
                "width": int(width),
                "height": int(height),
                "fps": fps if fps > 0 else "unknown"
            })
            cap.release()
        else:
            # Check if device exists but can't be opened
            cap = cv2.VideoCapture(index)
            if cap.isOpened():
                cameras.append({"index": index, "available": False})
    
    return cameras


def main():
    cameras = list_cameras()
    
    if not cameras:
        print("No cameras detected.")
        print(json.dumps({"cameras": [], "count": 0}, indent=2))
        return
    
    print(f"Found {len(cameras)} camera(s):\n")
    
    for cam in cameras:
        if cam.get("available"):
            print(f"  Camera {cam['index']}: {cam['width']}x{cam['height']} @ {cam['fps']} FPS")
        else:
            print(f"  Camera {cam['index']}: (unavailable)")
    
    print("\n" + json.dumps({"cameras": cameras, "count": len(cameras)}, indent=2))


if __name__ == "__main__":
    main()
