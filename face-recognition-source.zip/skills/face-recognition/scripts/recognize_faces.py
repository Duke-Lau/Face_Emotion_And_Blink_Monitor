#!/usr/bin/env python3
"""
Recognize faces by comparing against a database of known persons.
"""

import sys
import os
import argparse
import json
import numpy as np

try:
    import face_recognition
except ImportError:
    print("Error: face_recognition not installed. Run: pip install face_recognition", file=sys.stderr)
    sys.exit(1)


def load_face_database(database_path):
    """Load all face encodings from the database."""
    known_faces = {}
    
    if not os.path.exists(database_path):
        return known_faces
    
    # Iterate through person directories
    for person_name in os.listdir(database_path):
        person_dir = os.path.join(database_path, person_name)
        if not os.path.isdir(person_dir):
            continue
        
        person_encodings = []
        for filename in os.listdir(person_dir):
            if filename.endswith(".npy"):
                filepath = os.path.join(person_dir, filename)
                encoding = np.load(filepath)
                person_encodings.append(encoding)
        
        if person_encodings:
            # Use average of all encodings for this person
            known_faces[person_name.replace("_", " ").title()] = np.mean(person_encodings, axis=0)
    
    return known_faces


def recognize_faces_in_image(image_path, known_faces, tolerance=0.6, num_jitters=1):
    """Recognize faces in an image against known faces database."""
    image = face_recognition.load_image_file(image_path)
    
    # Find face locations
    face_locations = face_recognition.face_locations(image)
    
    # Get face encodings
    face_encodings = face_recognition.face_encodings(image, face_locations, num_jitters=num_jitters)
    
    results = []
    for i, (top, right, bottom, left) in enumerate(face_locations):
        face_result = {
            "face_id": i + 1,
            "location": {
                "top": top,
                "right": right,
                "bottom": bottom,
                "left": left
            },
            "recognized": False,
            "name": None,
            "confidence": 0.0
        }
        
        if i < len(face_encodings):
            face_encoding = face_encodings[i]
            
            # Compare against known faces
            best_match = None
            best_distance = float('inf')
            
            for name, known_encoding in known_faces.items():
                distance = face_recognition.face_distance([known_encoding], face_encoding)[0]
                if distance < best_distance:
                    best_distance = distance
                    best_match = name
            
            # Check if match is within tolerance
            if best_match and best_distance <= tolerance:
                face_result["recognized"] = True
                face_result["name"] = best_match
                face_result["confidence"] = round(1.0 - best_distance, 3)
            else:
                face_result["recognized"] = False
                face_result["name"] = "Unknown"
                face_result["confidence"] = round(1.0 - best_distance, 3) if best_distance != float('inf') else 0.0
        
        results.append(face_result)
    
    return results


def main():
    parser = argparse.ArgumentParser(description="Recognize faces against a database")
    parser.add_argument("--input", required=True, help="Input image file")
    parser.add_argument("--database", default="faces_db", help="Face database directory (default: faces_db)")
    parser.add_argument("--tolerance", type=float, default=0.6, help="Recognition tolerance (default: 0.6, lower = stricter)")
    parser.add_argument("--num-jitters", type=int, default=1, help="Number of jitters for encoding (default: 1)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.input):
        result = {"success": False, "error": f"File not found: {args.input}"}
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"Error: {result['error']}")
        sys.exit(1)
    
    try:
        # Load face database
        known_faces = load_face_database(args.database)
        
        if not known_faces:
            result = {
                "success": False,
                "error": f"No faces found in database '{args.database}'. Add faces using add_face.py first."
            }
            if args.json:
                print(json.dumps(result, indent=2))
            else:
                print(f"Error: {result['error']}")
            sys.exit(1)
        
        # Recognize faces
        faces = recognize_faces_in_image(args.input, known_faces, tolerance=args.tolerance, num_jitters=args.num_jitters)
        
        result = {
            "success": True,
            "input": args.input,
            "database": args.database,
            "known_persons": list(known_faces.keys()),
            "face_count": len(faces),
            "faces": faces
        }
        
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"Found {len(faces)} face(s) in {args.input}:")
            print(f"Database: {len(known_faces)} known person(s): {', '.join(known_faces.keys())}")
            print()
            for face in faces:
                loc = face["location"]
                if face["recognized"]:
                    print(f"  ✓ Face {face['face_id']}: {face['name']} ({face['confidence']*100:.1f}% confidence)")
                else:
                    print(f"  ? Face {face['face_id']}: Unknown ({face['confidence']*100:.1f}% confidence)")
        
    except Exception as e:
        result = {"success": False, "error": str(e)}
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
